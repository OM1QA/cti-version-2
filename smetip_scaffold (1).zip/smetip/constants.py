# Auto-extracted constants from your original app

SOURCE_CONFIDENCE = {
    "CISA KEV": 0.95,
    "CISA Advisories": 0.95,
    "NVD": 0.90,
    "OTX": 0.75,
    "Abuse.ch ThreatFox": 0.85,
    "Abuse.ch URLhaus": 0.85,
    "CISA Alerts": 0.95,
    "UK NCSC News": 0.92,
    "ENISA News": 0.90,
    "The Hacker News": 0.70,
    "BleepingComputer": 0.75,
    "Cisco Talos": 0.85,
    "Microsoft Security Blog": 0.85,
    "Palo Alto Unit 42": 0.85
}

# You can move other literals/regexes here later.
